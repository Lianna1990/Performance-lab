#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 0 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive1[] = "0xc563d91540 |0| |";
long WebSocketReceiveLen1   = sizeof(WebSocketReceive1) - 1;	// (record-time: 18 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive2[] = "{\"eventName\":\"ACK\",\"eventData\":null,\"eventGuid\":1571834351,\"nx.Topics\""
                        ":null,\"nx.Destination\":null,\"ACK\":{\"endpoint\":\"https://nexus-websocket-a."
                        "intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__ZgCns2lsMjy1DFnwIcrzq6Ow4i6"
                        "-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\",\"sendTime\":1571834349826}}";
long WebSocketReceiveLen2   = sizeof(WebSocketReceive2) - 1;	// (record-time: 292 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive3[] = " ";
long WebSocketReceiveLen3   = sizeof(WebSocketReceive3) - 1;	// (record-time: 1 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive4[] = "{\"eventName\":\"ACK\",\"eventData\":null,\"eventGuid\":1571834411,\"nx.Topics\""
                        ":null,\"nx.Destination\":null,\"ACK\":{\"sendTime\":1571834409816,\"endpoint\":\""
                        "https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__Z"
                        "gCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}";
long WebSocketReceiveLen4   = sizeof(WebSocketReceive4) - 1;	// (record-time: 292 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive5[] = " ";
long WebSocketReceiveLen5   = sizeof(WebSocketReceive5) - 1;	// (record-time: 1 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive6[] = "{\"eventName\":\"ACK\",\"eventData\":null,\"eventGuid\":1571834471,\"nx.Topics\""
                        ":null,\"nx.Destination\":null,\"ACK\":{\"sendTime\":1571834469816,\"endpoint\":\""
                        "https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__Z"
                        "gCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}";
long WebSocketReceiveLen6   = sizeof(WebSocketReceive6) - 1;	// (record-time: 292 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive7[] = " ";
long WebSocketReceiveLen7   = sizeof(WebSocketReceive7) - 1;	// (record-time: 1 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive8[] = "{\"eventName\":\"ACK\",\"eventData\":null,\"eventGuid\":1571834531,\"nx.Topics\""
                        ":null,\"nx.Destination\":null,\"ACK\":{\"sendTime\":1571834529869,\"endpoint\":\""
                        "https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__Z"
                        "gCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}";
long WebSocketReceiveLen8   = sizeof(WebSocketReceive8) - 1;	// (record-time: 292 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive9[] = " ";
long WebSocketReceiveLen9   = sizeof(WebSocketReceive9) - 1;	// (record-time: 1 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive10[] = "{\"eventName\":\"ACK\",\"eventData\":null,\"eventGuid\":1571834591,\"nx.Topics\""
                        ":null,\"nx.Destination\":null,\"ACK\":{\"sendTime\":1571834589814,\"endpoint\":\""
                        "https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__Z"
                        "gCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}";
long WebSocketReceiveLen10   = sizeof(WebSocketReceive10) - 1;	// (record-time: 292 bytes)

#endif
