Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("prod.uxcrowd.ru", 
		"URL=https://prod.uxcrowd.ru/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/landing/webflow.css", ENDITEM, 
		"Url=/assets/gulp/env.js", ENDITEM, 
		"Url=/assets/css/landing/uxcrowd.webflow.css", ENDITEM, 
		"Url=/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/library/jquery.js", ENDITEM, 
		"Url=/library/jquery.form.js", ENDITEM, 
		"Url=/library/FileSaver.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.js", ENDITEM, 
		"Url=/library/jquery.uploadfile.min.js", ENDITEM, 
		"Url=/assets/gulp/sup_js.js", ENDITEM, 
		"Url=/assets/gulp/app_js.js", ENDITEM, 
		"Url=/assets/js/main_js/mediaelement-and-player.js", ENDITEM, 
		"Url=/assets/js/main_js/init.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.rule.js", ENDITEM, 
		"Url=/assets/js/app_js/auth.interceptor.js", ENDITEM, 
		"Url=https://ulogin.ru/js/ulogin.js", ENDITEM, 
		"Url=/assets/gulp/admin_js.js", ENDITEM, 
		"Url=/assets/gulp/customer_js.js", ENDITEM, 
		"Url=/assets/gulp/blog_js.js", ENDITEM, 
		"Url=/assets/gulp/home_js.js", ENDITEM, 
		"Url=/assets/gulp/moderator_js.js", ENDITEM, 
		"Url=/assets/gulp/tester_js.js", ENDITEM, 
		"Url=/library/require.js", ENDITEM, 
		"Url=/assets/gulp/new_tester_js.js", ENDITEM, 
		"Url=/assets/js/main_js/path_controller.js", ENDITEM, 
		"Url=/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", ENDITEM, 
		"Url=/assets/js/main_js/main_route.js", ENDITEM, 
		"Url=/controller/controller_home/newMain.controller.js?bust=1571834274602", ENDITEM, 
		"Url=/controller/controller_home/login.controller.js?bust=1571834274602", ENDITEM, 
		"Url=/app.js?bust=1571834274602", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ru.json", 
		"URL=https://prod.uxcrowd.ru/assets/lang/ru.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"81492e6e-e1e3-4dc5-b30d-76e9bb5d2c99");

	web_url("home.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("headerGreenWhite.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/headerGreenWhite.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footer.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/footer.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_image("ux-logo-new-white.svg", 
		"Src=../../assets/images/ux-logo-new-white.svg", 
		"Snapshot=t6.inf", 
		EXTRARES, 
		"Url=/assets/fonts/glyphicons-halflings-regular.woff2", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=https://ulogin-stats.ru/visit/", ENDITEM, 
		"Url=/controller/controller_customer/home.controller.js?bust=1571834274602", ENDITEM, 
		"Url=/controller/controller_customer/header.controller.js?bust=1571834274602", ENDITEM, 
		"Url=/controller/controller_customer/ordersList.controller.js?bust=1571834274602", ENDITEM, 
		"Url=/controller/controller_customer/ordersListHeader.controller.js?bust=1571834274602", ENDITEM, 
		LAST);

	lr_start_transaction("login");

	web_add_cookie("dbl=a162d9ff57a83c815d7d1db86222acc7; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("fco2r34=a162d9ff57a83c815d7d1db86222acc7; DOMAIN=prod.uxcrowd.ru");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("X-XSRF-TOKEN", 
		"81492e6e-e1e3-4dc5-b30d-76e9bb5d2c99");

	web_url("modal-login.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_home/modal-login.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://vk.com/rtrg?p=VK-RTRG-208363-3NOqH", "Referer=https://flashdeals.aliexpress.com/ru.htm?aff_platform=promotion&cpt=1571834282937&sk=mgPQQgnA&aff_trace_key=090f30c0953e42eda2863da2b2adf3e9-1571834282937-09384-mgPQQgnA&terminal_id=4e6ce577e9214dbb8acb901320b51e28", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_submit_data("authentication", 
		"Action=https://prod.uxcrowd.ru/api/authentication", 
		"Method=POST", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=clientx3", ENDITEM, 
		"Name=password", "Value=654321", ENDITEM, 
		"Name=remember-me", "Value=undefined", ENDITEM, 
		"Name=submit", "Value=Login", ENDITEM, 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"354d1f31-e970-4057-91c8-5ffd6f45a1f8");

	web_url("account", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("main_template.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_customer/main_template.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html_2", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_customer/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("header.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_customer/header.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ordersList.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_customer/ordersList.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("waitingOrders", 
		"URL=https://prod.uxcrowd.ru/api/customer/waitingOrders", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/svg/left-menu-icons/plus-orange.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/images/test-stand.png", "Referer=https://prod.uxcrowd.ru/app-customer-home/list-orders", ENDITEM, 
		"Url=/assets/css/svg/logo-new.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	web_url("hist-orders", 
		"URL=https://prod.uxcrowd.ru/api/customer/hist-orders", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/svg/left-menu-icons/settings.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/left-menu-icons/insight.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/left-menu-icons/draft.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/left-menu-icons/list.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/logout.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/left-menu-icons/list-active.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/svg/close.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	web_url("orders", 
		"URL=https://prod.uxcrowd.ru/api/customer/orders", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-customer-home/list-orders\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Subscribe\",\"nx.Topics\":[\"*\"]}", 
		"IsBinary=0", 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571834349826\",\"eventData\":{\"sendTime\":1571834349826,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__ZgCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive1*/

	lr_start_transaction("new");

	web_add_cookie("intercom-session-fkbc3no8=SmR5VERDZjJranYyUzlyTGZBc3pOV0pPN3pEbDQyUmdTTVdUOE90NnhPVEY5cjdubUdvQWE2dDIzaXhVSDhGaS0tQzBiZGNXUklmNTRjSVFZcExFZTFsZz09--999cf1e3d1548d6713b7dce56df711fc4f5826ec; DOMAIN=prod.uxcrowd.ru");

	web_url("new.order.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_customer/new.order.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/list-orders", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/svg/left-menu-icons/plus-active.svg", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive2*/

	lr_think_time(17);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-customer-home/order?as=select_tester\"}}", 
		"IsBinary=0", 
		LAST);

	lr_end_transaction("new",LR_AUTO);

	lr_start_transaction("auditory");

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	lr_think_time(20);

	web_custom_request("draft", 
		"URL=https://prod.uxcrowd.ru/api/v2/customer/draft", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?as=select_tester", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"BodyBinary={\"introduction\":\"\\xD0\\x92\\xD0\\xBE \\xD0\\xB2\\xD1\\x80\\xD0\\xB5\\xD0\\xBC\\xD1\\x8F \\xD0\\xB8\\xD1\\x81\\xD1\\x81\\xD0\\xBB\\xD0\\xB5\\xD0\\xB4\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xBD\\xD0\\xB0 \\xD1\\x8D\\xD0\\xBA\\xD1\\x80\\xD0\\xB0\\xD0\\xBD\\xD0\\xB5 \\xD0\\xB1\\xD1\\x83\\xD0\\xB4\\xD1\\x83\\xD1\\x82 \\xD0\\xBF\\xD0\\xBE\\xD1\\x8F\\xD0\\xB2\\xD0\\xBB\\xD1\\x8F\\xD1\\x82\\xD1\\x8C\\xD1\\x81\\xD1\\x8F "
		"\\xD0\\xB7\\xD0\\xB0\\xD0\\xB4\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xB8 \\xD0\\xB2\\xD0\\xBE\\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD1\\x81\\xD1\\x8B.\\\\n\\\\n\\xD0\\x92 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD1\\x86\\xD0\\xB5\\xD1\\x81\\xD1\\x81\\xD0\\xB5 \\xD0\\xB2\\xD1\\x8B\\xD0\\xBF\\xD0\\xBE\\xD0\\xBB\\xD0\\xBD\\xD0\\xB5\\xD0\\xBD\\xD0\\xB8\\xD1\\x8F \\xD0\\xB7\\xD0\\xB0\\xD0\\xB4\\xD0\\xB0\\xD0\\xBD\\xD0\\xB8\\xD0\\xB9 \\xD0\\xB2\\xD0\\xB0\\xD0\\xB6\\xD0\\xBD\\xD0\\xBE, "
		"\\xD1\\x87\\xD1\\x82\\xD0\\xBE\\xD0\\xB1\\xD1\\x8B \\xD0\\xB2\\xD1\\x8B \\xD1\\x80\\xD0\\xB0\\xD0\\xB7\\xD0\\xBC\\xD1\\x8B\\xD1\\x88\\xD0\\xBB\\xD1\\x8F\\xD0\\xBB\\xD0\\xB8 \\xD0\\xB2\\xD1\\x81\\xD0\\xBB\\xD1\\x83\\xD1\\x85 \\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xBE\\xD0\\xB3\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x80\\xD0\\xB8\\xD0\\xB2\\xD0\\xB0\\xD0\\xBB\\xD0\\xB8, \\xD0\\xBA\\xD0\\xB0\\xD0\\xBA\\xD0\\xB8\\xD0\\xB5 "
		"\\xD1\\x81\\xD0\\xBB\\xD0\\xBE\\xD0\\xB6\\xD0\\xBD\\xD0\\xBE\\xD1\\x81\\xD1\\x82\\xD0\\xB8 \\xD1\\x83 \\xD0\\xB2\\xD0\\xB0\\xD1\\x81 \\xD0\\xB2\\xD0\\xBE\\xD0\\xB7\\xD0\\xBD\\xD0\\xB8\\xD0\\xBA\\xD0\\xB0\\xD1\\x8E\\xD1\\x82 \\xD0\\xB8 \\xD0\\xBF\\xD0\\xBE\\xD1\\x87\\xD0\\xB5\\xD0\\xBC\\xD1\\x83. \",\"targetSite\":\"https://pornhub.com\",\"testTitle\":\"huehuehue\",\"testType\":\"SITE\"}", 
		EXTRARES, 
		"Url=/assets/images/uxcrowd-logo-green-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		"Url=/assets/images/avatar-gray-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		"Url=/assets/images/burger-gray-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571834409816\",\"eventData\":{\"sendTime\":1571834409816,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__ZgCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive3*/

	/*Connection ID 0 received buffer WebSocketReceive4*/

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-customer-home/order?id=16960808\"}}", 
		"IsBinary=0", 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"354d1f31-e970-4057-91c8-5ffd6f45a1f8");

	lr_think_time(18);

	web_url("getMetrics", 
		"URL=https://prod.uxcrowd.ru/api/v2/customer/getMetrics?testType=SITE", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getTemplates", 
		"URL=https://prod.uxcrowd.ru/api/v2/customer/getTemplates?testType=SITE", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_custom_request("updateOrderAudience", 
		"URL=https://prod.uxcrowd.ru/api/v2/customer/updateOrderAudience", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"Body={\"orderId\":16960808,\"testerType\":\"OUR\",\"participantGroupDTO\":[{\"ageRange\":{\"min\":24,\"max\":29},\"children\":\"ANY\",\"count\":50,\"educations\":[\"COMMON\",\"MIDDLE_FULL\",\"MIDDLE_SPEC\",\"HIGH_NOT_FULL\",\"HIGH\"],\"familyStatus\":\"ANY\",\"gender\":\"ANY\",\"groupName\":\"opopopopopo\",\"incomeRange\":{\"min\":0,\"max\":55000},\"socialStatuses\":[\"STUDENT\",\"UNEMPLOYED\",\"HOUSEWIFE\",\"FREELANCER\",\"WORKER\",\"SPECIALIST\",\"CHIEF_DEPT\"],\"ordinal\":0}]}", 
		EXTRARES, 
		"Url=/assets/images/uxcrowd-logo-white-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		"Url=/assets/images/avatar-white-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		"Url=/assets/images/burger-white-mobile.svg", "Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960808", ENDITEM, 
		LAST);

	lr_end_transaction("auditory",LR_AUTO);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571834469816\",\"eventData\":{\"sendTime\":1571834469816,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__ZgCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive5*/

	lr_start_transaction("zadan");

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-customer-home/order?id=16960808\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive6*/

	lr_end_transaction("zadan",LR_AUTO);

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("X-XSRF-TOKEN", 
		"354d1f31-e970-4057-91c8-5ffd6f45a1f8");

	lr_think_time(16);

	web_custom_request("updateOrderSteps", 
		"URL=https://prod.uxcrowd.ru/api/v2/customer/updateOrderSteps", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960809", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"Body={\"orderId\":16960809,\"steps\":[{\"question\":\"rrrrrr\",\"stepType\":\"TEXT\",\"orderNum\":0}],\"metrics\":[]}", 
		LAST);

	web_url("calculatePrice", 
		"URL=https://prod.uxcrowd.ru/api/customer/calculatePrice?orderId=16960809", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-customer-home/order?id=16960809", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(12);

	lr_start_transaction("1_transaction");

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571834589814\",\"eventData\":{\"sendTime\":1571834589814,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-xRZ5TjIAR5YYs5RLtmuccsmXsVVg9U__ZgCns2lsMjy1DFnwIcrzq6Ow4i6-PzQ-Trr3dojJFKD2poxR2IuCytAPw8IPeDaSTvwo\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive9*/

	/*Connection ID 0 received buffer WebSocketReceive10*/

	return 0;
}