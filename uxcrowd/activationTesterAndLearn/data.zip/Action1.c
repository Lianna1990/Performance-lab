Action1()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("activate", 
		"URL=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/gulp/sup_css.css", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/css/landing/webflow.css", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/css/landing/uxcrowd.webflow.css", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/library/jquery.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/env.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/css/landing/YouTube.HD.Thumbnail.css", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/library/jquery.form.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/sup_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/library/jquery.uploadfile.min.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/library/FileSaver.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/validation.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/init.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/validation.rule.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/app_js/auth.interceptor.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/mediaelement-and-player.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/app_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=https://ulogin.ru/js/ulogin.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/admin_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/customer_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/blog_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/home_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/moderator_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/new_tester_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/library/require.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/path_controller.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/gulp/tester_js.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/assets/js/main_js/main_route.js", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ru.json", 
		"URL=https://prod.uxcrowd.ru/assets/lang/ru.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/controller/controller_home/activate.controller.js?bust=1571905934771", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=/app.js?bust=1571905934771", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"8fc46968-5a10-4053-936c-1b1f742c36d9");

	web_url("activate.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_home/activate.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("new-footer.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_home/new-footer.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/svg/youtube.svg", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		LAST);

	web_url("activate_exist", 
		"URL=https://prod.uxcrowd.ru/api/activate_exist?key=96224432842850756164", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_custom_request("activate_2", 
		"URL=https://prod.uxcrowd.ru/api/activate", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"key\":\"96224432842850756164\",\"password\":\"654321\"}", 
		LAST);

	web_submit_data("authentication", 
		"Action=https://prod.uxcrowd.ru/api/authentication", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=test1009", ENDITEM, 
		"Name=password", "Value=654321", ENDITEM, 
		"Name=remember-me", "Value=false", ENDITEM, 
		"Name=submit", "Value=Login", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("X-XSRF-TOKEN", 
		"670c9a3a-ff8a-4b40-8c48-e0170fa06d33");

	web_url("account", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../controller/controllers_testers/controller_new_tester/home.controller.js?bust=1571905934771", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=../controller/controllers_testers/controller_new_tester/header.controller.js?bust=1571905934771", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		"Url=../app.js?bust=1571905934771", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		LAST);

	web_url("home.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("header.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("welcome.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/welcome.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/js/home_js/youtube.js?_=1571905934648", "Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", ENDITEM, 
		LAST);

	web_add_cookie("newTesterState=welcome; DOMAIN=prod.uxcrowd.ru");

	web_url("has-completed-video", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/images/logo-final.png", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/welcome", ENDITEM, 
		"Url=/assets/images/test-stand.png", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/welcome", ENDITEM, 
		"Url=/assets/images/16-9.png", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/welcome", ENDITEM, 
		LAST);

	web_url("has-completed-video_2", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/activate?key=96224432842850756164", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("intercom-id-fkbc3no8=63af49aa-656d-4fa6-9099-7ff61ece54dd; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("newTesterState=; DOMAIN=prod.uxcrowd.ru");

	web_url("instruction_step_1.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/instruction_step_1.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/welcome", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/images/google-chrome-1.svg", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction1", ENDITEM, 
		"Url=/assets/images/yandex.browser.svg", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction1", ENDITEM, 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-new-tester-home/instruction1\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"eventName\":\"nx.Subscribe\",\"nx.Topics\":[\"*\"]}", 
		"IsBinary=0", 
		LAST);

	web_url("has-completed-video_3", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/welcome", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive1*/

	web_websocket_send("ID=1", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-new-tester-home/instruction1\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_send("ID=1", 
		"Buffer={\"eventName\":\"nx.Subscribe\",\"nx.Topics\":[\"*\"]}", 
		"IsBinary=0", 
		LAST);

	web_add_cookie("intercom-session-fkbc3no8=MERSWmNFa3RpbFZ1ZkRyRmRUQy9ucytmLzdOTzErRGlCUHhmYmtWdmV0NlVKeWdZK2ppRFZlUHo4YXk4WWpsay0tTFN2ZlpET0NIZnNBT3lDdlBma3gxdz09--8ddfe01105188dfc432ea87415e9ec517a271395; DOMAIN=prod.uxcrowd.ru");

	web_url("instruction_step_2.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/instruction_step_2.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction1", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/images/download-arr.png", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction2", ENDITEM, 
		LAST);

	web_url("has-completed-video_4", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction1", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("intercom-session-fkbc3no8=a090ZVI5MGRPR3VJWFNETWNKY2pFTGxGTXdHZDI1TGRzcG9ZaVFObHlXWFJGQU91alBvb1ZYTndQa0ZNeE1COC0tZ0NmU0t5SzlBWUs4TFZBS1JqUHFIdz09--301062422ca9a6faea8cd03be445a6711c197946; DOMAIN=prod.uxcrowd.ru");

	web_url("instruction_step_3.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/instruction_step_3.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction2", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("intercom-session-fkbc3no8=VEJPTTBIUXBCeTk3ODNNZ3RFb0VLNzdqSkY2Vm9sYlUxTXFVQTMyUlFzSGl2ekhtcm00eUVzMlM4dFFnMlFIdy0tQ1IyYm9OR0NzWGQ1ajFySk9JeWFIUT09--85205916489620ad5c4da473edb2a338b074298f; DOMAIN=prod.uxcrowd.ru");

	web_url("has-completed-video_5", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction2", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/images/ezgif-1-0f931c46a0.gif", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", ENDITEM, 
		"Url=/assets/images/task_moving.gif", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", ENDITEM, 
		"Url=../v2/plugin/getLastVersion?pluginType=WEB&environmentType=DO_PROD", "Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", ENDITEM, 
		LAST);

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("instruction3", 
		"URL=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/gulp/sup_css.css", ENDITEM, 
		"Url=../assets/css/landing/webflow.css", ENDITEM, 
		"Url=../assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=../assets/css/landing/uxcrowd.webflow.css", ENDITEM, 
		"Url=../assets/lang/ru.json", ENDITEM, 
		"Url=../controller/controllers_testers/controller_new_tester/header.controller.js?bust=1571905946897", ENDITEM, 
		"Url=../controller/controllers_testers/controller_new_tester/home.controller.js?bust=1571905946897", ENDITEM, 
		"Url=../app.js?bust=1571905946897", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("X-XSRF-TOKEN", 
		"670c9a3a-ff8a-4b40-8c48-e0170fa06d33");

	web_url("account_2", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html_2", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("header.html_2", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("instruction_step_3.html_2", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_new_tester/instruction_step_3.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("has-completed-video_6", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_custom_request("create", 
		"URL=https://prod.uxcrowd.ru/api/stats/create", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"orderId\":\"4\",\"screenName\":\"START_PLUGIN\",\"testerId\":493253217}", 
		LAST);

	web_url("has-completed-video_7", 
		"URL=https://prod.uxcrowd.ru/api/tester/has-completed-video", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/app-new-tester-home/instruction3", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_gcl_au=1.1.1478294464.1571211453; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ym_d=1571211453; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ym_uid=1571211453779728618; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ga=GA1.2.1566072516.1571211453; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_fbp=fb.1.1571211453213.1992205076; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_hjid=af551394-e1bf-4a9c-a802-a34127cb6932; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("supportOnlineTalkID=NQtz7VT3tBWegZp7HJtH7uKtsdpFCABR; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("mp_7e8c1704afe136d673068a7cf50876d7_mixpanel=%7B%22distinct_id%22%3A%20%2216dd3802179263-0d3fe0e95c886c-b363e65-1fa400-16dd380217ab9b%22%2C%22%24device_id%22%3A%20%2216dd3802179263-0d3fe0e95c886c-b363e65-1fa400-16dd380217ab9b%22%2C%22%24search_engine%22%3A%20%22google%22%2C%22%24initial_referrer%22%3A%20%22https%3A%2F%2Fwww.google.com%2F%22%2C%22%24initial_referring_domain%22%3A%20%22www.google.com%22%7D; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("s_l_p=qeyRO8VpGnitxcwBhcf5O2ZxS1S0dZZl; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("dbl=067bcf8ea81a05fc78bfa9bda30ef4d5; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("fco2r34=067bcf8ea81a05fc78bfa9bda30ef4d5; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("intercom-id-fkbc3no8=285e199c-750a-41f4-8079-bd580c8fdef6; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("userId=493253208; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("intercom-session-fkbc3no8=Y2xOQyt0Y3lqcUZYR21MM0Q4RnJLVVZJZGpuZWV5RXh4NkpxbS9Ic3FWeldnS1dwVHpKSjlESU0xTlYxYjlIbC0tTldWZFkvYWtoSE5wdXdtUWFSMnVzdz09--c8c4839797826ed0ec239db79ca05101885c8e5d; DOMAIN=prod.uxcrowd.ru");

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("account_3", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("XSRF-TOKEN=670c9a3a-ff8a-4b40-8c48-e0170fa06d33; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("remember-me=NzZscE9YcG5GTXBtakN5QVRuVCUyRjVnJTNEJTNEOjl2RHlFbmFiUlhTWmhpdmhvaER1eVElM0QlM0Q; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("JSESSIONID=B818227BAD385634111CD351195E600D; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("CSRF-TOKEN=670c9a3a-ff8a-4b40-8c48-e0170fa06d33; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("intercom-session-fkbc3no8=YlI5YnptMzRqaE1ZMW1zTDd1Rm85cW1rV1U4TlZzYW1FeGR4NWRsQWV1Y0V2STlrYWszbU9EcVhQdGV4bTN0dC0teTVQV3ZZTTUxMUJVYUhlTmZvWEVldz09--b35e9e3979547f4fd708ae2eccb42074660a7c65; DOMAIN=prod.uxcrowd.ru");

	web_url("order-info", 
		"URL=https://prod.uxcrowd.ru/api/tester/order-info?id=4", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/fonts/Open%20Sans/RjgO7rYTmqiVp7vzi-Q5UYX0hVgzZQUfRDuZrPvH3D8.woff2", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/fonts/Open%20Sans/cJZKeOuBrn4kERxqtaUH3ZBw1xU1rKptJj_0jans920.woff2", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive2*/

	web_websocket_send("ID=2", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-new-tester-home/instruction3\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive3*/

	web_websocket_send("ID=2", 
		"Buffer={\"eventName\":\"nx.Subscribe\",\"nx.Topics\":[\"*\"]}", 
		"IsBinary=0", 
		LAST);

	web_add_auto_header("Origin", 
		"chrome-extension://dfhbnhciflaelghihmdfldmlpfbiobgc");

	web_add_auto_header("X-XSRF-TOKEN", 
		"d2c79ea2-45ca-4dfe-b149-a436c891b237");

	lr_think_time(5);

	web_custom_request("update", 
		"URL=https://prod.uxcrowd.ru/api/stats/update", 
		"Method=PUT", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"Body={\"orderId\":\"4\",\"id\":1488,\"screenName\":\"SCREEN_CAPTURE\"}", 
		LAST);

	web_custom_request("create-task", 
		"URL=https://prod.uxcrowd.ru/api/tester/create-task?orderId=4", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"archName\":\"x86_64\",\"numOfProcessors\":4,\"os\":\"Windows NT 10.0  Win64\",\"processorModel\":\"Intel(R) Core(TM) i3-8100 CPU @ 3.60GHz\",\"browserVersion\":\"Chrome 77.0.3865.120\",\"screenResolution\":\"1920x1080\",\"geoLocation\":null}", 
		LAST);

	web_custom_request("update_2", 
		"URL=https://prod.uxcrowd.ru/api/stats/update", 
		"Method=PUT", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"Body={\"orderId\":\"4\",\"id\":1488,\"screenName\":\"FINAL_INSTRUCTION\"}", 
		LAST);

	web_custom_request("update_3", 
		"URL=https://prod.uxcrowd.ru/api/stats/update", 
		"Method=PUT", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"Body={\"orderId\":\"4\",\"id\":1488,\"screenName\":\"START_PLUGIN\"}", 
		EXTRARES, 
		"Url=https://vk.com/rtrg?p=VK-RTRG-208363-3NOqH", "Referer=https://ru.aliexpress.com/", ENDITEM, 
		LAST);

	web_websocket_send("ID=2", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571905989035\",\"eventData\":{\"sendTime\":1571905989035,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-eKdTPXLkUXkzEMvJ3-PsHu_lE7jyttl98TJlWFdqSXKWiYEDqqUcrPUsyKTvYMru0RwbDdgiR5Fm7IpCCyuRZK0AxF2J-GMNk5Qk\"}}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive4*/

	/*Connection ID 2 received buffer WebSocketReceive5*/

	lr_think_time(63);

	web_websocket_send("ID=2", 
		"Buffer={\"eventName\":\"nx.UserPresence\",\"eventData\":{\"current_page\":\"https://prod.uxcrowd.ru/app-new-tester-home/instruction3\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_send("ID=2", 
		"Buffer={\"eventName\":\"nx.Ping\",\"eventGuid\":\"1571906030031\",\"eventData\":{\"sendTime\":1571906030031,\"endpoint\":\"https://nexus-websocket-a.intercom.io/pubsub/5-eKdTPXLkUXkzEMvJ3-PsHu_lE7jyttl98TJlWFdqSXKWiYEDqqUcrPUsyKTvYMru0RwbDdgiR5Fm7IpCCyuRZK0AxF2J-GMNk5Qk\"}}", 
		"IsBinary=0", 
		LAST);

	web_websocket_close("ID=2", 
		"Code=1000", 
		LAST);

	return 0;
}