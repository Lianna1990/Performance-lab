Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("do-prod-side-tester-welcome", 
		"URL=https://uxcrowd.test-app.link/do-prod-side-tester-welcome?ac=16958850", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/webflow.css", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/uxcrowd.webflow.css", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/env.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.form.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.uploadfile.min.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/validation.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/FileSaver.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/sup_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/app_js/auth.interceptor.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/init.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/mediaelement-and-player.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/app_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/validation.rule.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://ulogin.ru/js/ulogin.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/admin_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/customer_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/home_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/blog_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/moderator_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/new_tester_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/tester_js.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/path_controller.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/require.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/main_route.js", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ru.json", 
		"URL=https://prod.uxcrowd.ru/assets/lang/ru.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/controller/controllers_testers/controller_side_tester/home.controller.js?bust=1571645156366", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"a0aeaea8-14f4-4f23-aa78-7475b5808fe9");

	web_url("index1.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/react/sideTesterWelcome/index1.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/app.js?bust=1571645156366", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		LAST);

	web_url("welcome.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_testers/tmpl_side_tester/welcome.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("logo.41e83db4.svg", 
		"URL=https://prod.uxcrowd.ru/static/media/logo.41e83db4.svg", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("X-XSRF-TOKEN", 
		"a0aeaea8-14f4-4f23-aa78-7475b5808fe9");

	web_url("getLastVersion", 
		"URL=https://prod.uxcrowd.ru/api/v2/plugin/getLastVersion?pluginType=WEB&environmentType=PROD", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ulogin-stats.ru/visit/", "Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", ENDITEM, 
		LAST);

	web_add_cookie("dbl=11ca07063e1c0cbb6af41c83f7b2cb31; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("fco2r34=11ca07063e1c0cbb6af41c83f7b2cb31; DOMAIN=prod.uxcrowd.ru");

	web_add_auto_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_custom_request("tester-integration", 
		"URL=https://prod.uxcrowd.ru/api/tester-integration", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"acc\":\"16958850\",\"email\":\"vgfkjhnkghfs@mail.ru\"}", 
		LAST);

	web_custom_request("authentication", 
		"URL=https://prod.uxcrowd.ru/api/authentication?password=GdfRRee34&remember-me=true&submit=Login&username=vgfkjhnkghfs%40mail.ru", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("X-XSRF-TOKEN", 
		"eb20aae2-69fd-489c-8922-e738636f0c6b");

	web_url("account", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://prod.uxcrowd.ru");

	web_custom_request("create", 
		"URL=https://prod.uxcrowd.ru/api/stats/create", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/side-tester-welcome/welcome?ac=16958850&_branch_match_id=714738461764788274", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"orderId\":\"16958850\",\"screenName\":\"ENTER_EMAIL\",\"testerId\":493253142,\"errorMessage\":null}", 
		LAST);

	web_add_cookie("intercom-id-fkbc3no8=94941108-42d5-47c7-a6f6-d0c741ffe294; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("userId=493253139; DOMAIN=prod.uxcrowd.ru");

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("account_2", 
		"URL=https://prod.uxcrowd.ru/api/account", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("CSRF-TOKEN=a0aeaea8-14f4-4f23-aa78-7475b5808fe9; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("XSRF-TOKEN=eb20aae2-69fd-489c-8922-e738636f0c6b; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("remember-me=eTBEc2tSWjZsalB4b2F1WGlLb3BDUSUzRCUzRDo1M29LSjNLblJmcWh4bEtFSUZsazVRJTNEJTNE; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("JSESSIONID=159E9C60C69299CA58CC4B399CA8D793; DOMAIN=prod.uxcrowd.ru");

	web_url("order-info", 
		"URL=https://prod.uxcrowd.ru/api/tester/order-info?id=16958850", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/fonts/Open%20Sans/RjgO7rYTmqiVp7vzi-Q5UYX0hVgzZQUfRDuZrPvH3D8.woff2", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/fonts/Open%20Sans/cJZKeOuBrn4kERxqtaUH3ZBw1xU1rKptJj_0jans920.woff2", "Referer=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", ENDITEM, 
		LAST);

	return 0;
}