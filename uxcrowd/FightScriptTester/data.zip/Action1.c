Action1()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("merchants.json", 
		"URL=https://www.gstatic.com/autofill/weekly/merchants.json", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_add_cookie("_gcl_au=1.1.15781124.1568185906; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ga=GA1.2.2087808476.1568185907; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ym_d=1568185907; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_ym_uid=15681859071015399557; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_fbp=fb.1.1568185906935.53944984; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("supportOnlineTalkID=isIvBrmtZzTP94QE4xLT02k0a2IQylzC; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("_hjid=0e6b5960-f309-4739-b02b-a7ef295a1740; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("mp_7e8c1704afe136d673068a7cf50876d7_mixpanel=%7B%22distinct_id%22%3A%20%2216d1f29f5c82b7-068b903570cf73-5b1c3711-15f900-16d1f29f5c967a%22%2C%22%24device_id%22%3A%20%2216d1f29f5c82b7-068b903570cf73-5b1c3711-15f900-16d1f29f5c967a%22%2C%22%24initial_referrer%22%3A%20%22%24direct%22%2C%22%24initial_referring_domain%22%3A%20%22%24direct%22%7D; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("dbl=67f6843586a1f8934b9a141f75553160; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("fco2r34=67f6843586a1f8934b9a141f75553160; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("userId=493253092; DOMAIN=prod.uxcrowd.ru");

	web_add_cookie("intercom-id-fkbc3no8=1b59e3f0-760d-4873-9f5b-02d045c217a9; DOMAIN=prod.uxcrowd.ru");

	web_url("prod.uxcrowd.ru", 
		"URL=https://prod.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=beta&milestone=78", "Referer=", ENDITEM, 
		"Url=https://www.gstatic.com/autofill/hourly/bins.json", "Referer=", ENDITEM, 
		"Url=/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/landing/webflow.css", ENDITEM, 
		"Url=/assets/css/landing/uxcrowd.webflow.css", ENDITEM, 
		"Url=/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/assets/gulp/env.js", ENDITEM, 
		"Url=/library/jquery.js", ENDITEM, 
		"Url=/library/jquery.form.js", ENDITEM, 
		"Url=/library/jquery.uploadfile.min.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.js", ENDITEM, 
		"Url=/library/FileSaver.js", ENDITEM, 
		"Url=/assets/gulp/sup_js.js", ENDITEM, 
		"Url=/assets/js/main_js/init.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.rule.js", ENDITEM, 
		"Url=/assets/js/app_js/auth.interceptor.js", ENDITEM, 
		"Url=/assets/gulp/app_js.js", ENDITEM, 
		"Url=/assets/js/main_js/mediaelement-and-player.js", ENDITEM, 
		"Url=/assets/gulp/admin_js.js", ENDITEM, 
		"Url=/assets/gulp/customer_js.js", ENDITEM, 
		"Url=/assets/gulp/blog_js.js", ENDITEM, 
		"Url=/assets/gulp/home_js.js", ENDITEM, 
		"Url=/assets/gulp/moderator_js.js", ENDITEM, 
		"Url=/assets/gulp/new_tester_js.js", ENDITEM, 
		"Url=/assets/gulp/tester_js.js", ENDITEM, 
		"Url=/library/require.js", ENDITEM, 
		"Url=/assets/js/main_js/path_controller.js", ENDITEM, 
		"Url=/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", ENDITEM, 
		"Url=/assets/js/main_js/main_route.js", ENDITEM, 
		"Url=/assets/lang/ru.json", ENDITEM, 
		"Url=/controller/controller_home/newMain.controller.js?bust=1572340102388", ENDITEM, 
		"Url=/controller/controller_home/login.controller.js?bust=1572340102388", ENDITEM, 
		"Url=/app.js?bust=1572340102388", ENDITEM, 
		LAST);

	web_add_cookie("CONSENT=YES+RU.ru+20161009-18-0; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIsI0B; DOMAIN=accounts.google.com");

	web_add_cookie("OGPC=19013527-1:19013805-1:; DOMAIN=accounts.google.com");

	web_add_cookie("ANID=AHWqTUk4-KLvFKHR1vJ6KgeZCsCXUp3nzw2eCzpjV95GrWH5fJx9adUpi-kBCq0C; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2019-10-08-14; DOMAIN=accounts.google.com");

	web_add_cookie("NID=188=OcmjYnJJFjyZ2po9ZAQ2MngnmWDnl6hvQ1JiMGPo8h4L5-iBvEo33Lxm3q7mG0pggOq6AM0fAeNbrJ8X9zTvz-BJpoqJyoxy2HJAg4oNpeh40-9gnwWjsbJvSzHmTT6aQwEjDcx5ubSm-vQFQIEJ1DSSQ2hnWU3Sca6i8mE2r7sJxGa30l5myXq2fiDCuOn8OxCvEU-68QG4; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:1Y7RfjLUf3-CXkUtcCsl9Jyt-VrsKKbLf1UiW5m5xcaZ4HlfX7wJVPF6mm73Sl9MgOX6d0TiCrc5eIlBNDWHbsR4xkbSCBD9Nv7TDLuazbvbGTrglHz0NGYabH1a5GrYTFSiTyB0he4o57ktJ5QSjo2dtw6XxmyJ2wGnQq-2TE9ryiyC6KFOH4EGnlLtWzaoJR0Lb_m6IpiXKQ:h9UcvW0sb2lOIKX_; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI56RVs3OvBv5R664-QzZX0skQFtqqsDnVo-u5VjhgEK91QvS_QTYUzTLDEEwbR7KpUfa6HF; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_url("headerGreenWhite.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/headerGreenWhite.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footer.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/footer.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("utm1=1:0ca85cee-80e3-4537-b74b-73242d423645; DOMAIN=ulogin-stats.ru");

	web_url("prod.uxcrowd.ru_2", 
		"URL=https://prod.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/landing/youtube-play.svg", "Referer=https://prod.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/assets/images/nl-home-girl.svg", ENDITEM, 
		"Url=/assets/images/nl-home-top-blot.svg", ENDITEM, 
		"Url=/assets/images/burger-white-mobile.svg", ENDITEM, 
		"Url=/assets/images/uxcrowd-logo-new.svg", ENDITEM, 
		"Url=/assets/images/uxcrowd-logo-white-mobile.svg", ENDITEM, 
		"Url=/assets/images/avatar-white-mobile.svg", ENDITEM, 
		"Url=/assets/images/youtube-colored.svg", ENDITEM, 
		"Url=/assets/images/facebook-colored.svg", ENDITEM, 
		"Url=/assets/images/google-play-btn.png", ENDITEM, 
		"Url=/assets/images/nl-home-work-arrow.svg", ENDITEM, 
		"Url=/assets/images/nl-home-work-blot-rect.svg", ENDITEM, 
		"Url=/assets/images/nl-home-work-blot-circle.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-1.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-2.svg", ENDITEM, 
		"Url=/assets/images/nl-home-helpful-block-3.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-2.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-3.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-1.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-4.svg", ENDITEM, 
		"Url=/assets/images/nl-home-clients-logo-5.svg", ENDITEM, 
		"Url=/assets/images/egor_golubev.png", ENDITEM, 
		"Url=/assets/images/svetlana_gorshkova.jpg", ENDITEM, 
		"Url=/assets/images/ildar_mullahmetov.png", ENDITEM, 
		"Url=/assets/images/nl-home-center-blot.png", ENDITEM, 
		"Url=/assets/images/nl-home-clients-blot-mobile.svg", ENDITEM, 
		"Url=/assets//images/question.png", ENDITEM, 
		"Url=/assets/images/Rectangle%205.2.png", ENDITEM, 
		"Url=/assets/images/nl-home-blot-bottom-mobile.svg", ENDITEM, 
		"Url=/assets/images/ux-logo-new-white.svg", ENDITEM, 
		"Url=/assets/images/youtube.svg", ENDITEM, 
		"Url=/assets/images/facebook.svg", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://use.typekit.net/hym5rnq.js", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/fullHashes:find?$req="
		"ChwKDGdvb2dsZWNocm9tZRIMNzguMC4zOTA0LjcwEhsKDQgFEAYYASIDMDAxMAEQmrYHGgIYCJ5PfVYSGwoNCAEQBhgBIgMwMDEwARDszwYaAhgItSx4nhIbCg0IBxAGGAEiAzAwMTABEKGhBhoCGAgcA2nVEhkKDQgBEAYYASIDMDAxMAMQFBoCGAhKo8bvEhoKDQgBEAgYASIDMDAxMAQQyRgaAhgIlw2kURIZCg0ICRAGGAEiAzAwMTAGEAIaAhgIvPFhSxIaCg0IDxAGGAEiAzAwMTABEO4VGgIYCFfdEYgSGQoNCAkQBhgBIgMwMDEwARAVGgIYCL-ldC8SGQoNCAoQCBgBIgMwMDEwARAFGgIYCHbHsa8SGgoNCAgQBhgBIgMwMDEwARCOBxoCGAh6Fb23EhoKDQgNEAYYASIDMDAxMAEQxVIaAhgIBBqgThIbCg0IAxAGGAEiAzAwMTABEObMBhoCGAhjcVn0EhsKDQgOEAYYAS"
		"IDMDAxMAEQ4L4CGgIYCEXVcLcaLAgBCAMIBQgGCAcICAgJCAoIDQgOCA8IEBABEAgaBgoEug0AVCABIAMgBCAG&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=https://i.ytimg.com/vi/Q2CnE_Nlsbc/sddefault.jpg", ENDITEM, 
		"Url=https://ulogin-stats.ru/visit/", ENDITEM, 
		LAST);

	web_add_cookie("VISITOR_INFO1_LIVE=CjioUeOuhRc; DOMAIN=www.youtube.com");

	web_add_cookie("CONSENT=YES+RU.ru+20161009-18-0; DOMAIN=www.youtube.com");

	web_add_cookie("PREF=al=ru&f1=50000000; DOMAIN=www.youtube.com");

	web_add_cookie("GPS=1; DOMAIN=www.youtube.com");

	web_add_cookie("_fbp=fb.1.1570544472947.115458815; DOMAIN=googleads.g.doubleclick.net");

	web_add_cookie("IDE=AHWqTUnv4u_R2s6JBE_zHx63iSF_mG8QBfFiEHYoMXeHtbdizQaRtYGiVPDJYaWs; DOMAIN=googleads.g.doubleclick.net");

	web_add_cookie("_fbp=fb.1.1570544472947.115458815; DOMAIN=static.doubleclick.net");

	web_add_cookie("IDE=AHWqTUnv4u_R2s6JBE_zHx63iSF_mG8QBfFiEHYoMXeHtbdizQaRtYGiVPDJYaWs; DOMAIN=static.doubleclick.net");

	web_url("Q2CnE_Nlsbc", 
		"URL=https://www.youtube.com/embed/Q2CnE_Nlsbc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://googleads.g.doubleclick.net/pagead/id", ENDITEM, 
		"Url=https://static.doubleclick.net/instream/ad_status.js", ENDITEM, 
		LAST);

	web_url("generate_204", 
		"URL=https://www.youtube.com/generate_204?3e-20Q", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.youtube.com/embed/Q2CnE_Nlsbc", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=beta&prodversion=78.0.3904.70&lang=ru&acceptformat=crx3&x=id%3Daapocclcgogkmnckokdopfmhonfmgoek%26v%3D0.10%26installedby%3Dinternal%26uc&x=id%3Daohghmighlieiainnegkcijnfilokake%26v%3D0.10%26installedby%3Dinternal%26uc&x=id%3Dapdfllckaahabafndbhieahigkjlhalf%26v%3D14.1%26installedby%3Dinternal%26uc&x="
		"id%3Dblndkmebkmenignoajhoemebccmmfjib%26v%3D1.4.9%26installedby%3Dinternal%26uc&x=id%3Dblpcfgokakmgnkcojhhkbfbldkacnbeo%26v%3D4.2.8%26installedby%3Dinternal%26uc&x=id%3Deelcnbccaccipfolokglfhhmapdchbfg%26v%3D2.3.1%26installedby%3Dinternal%26uc&x=id%3Dehafadccdcdedbhcbddihehiodgcddpl%26v%3D1.1.2%26installedby%3Dinternal%26uc&x=id%3Dfelcaaldnbdncclmgdcncolpebgiejap%26v%3D1.2%26installedby%3Dinternal%26uc&x=id%3Dghbmnnjooekpmoecnnnilnnbdlolhkhi%26v%3D1.7%26installedby%3Dexternal%26uc&x="
		"id%3Dnmmhkkegccagdldgiimedpiccmgmieda%26v%3D1.0.0.5%26installedby%3Dother%26uc&x=id%3Dpjkljhegncpnkpknbcohdijeoejaedia%26v%3D8.2%26installedby%3Dinternal%26uc&x=id%3Dpkedcjkdefgpdelpbcmbmeomcjbeemfm%26v%3D7819.902.0.1%26installedby%3Dother%26uc&x=id%3Defaidnbmnnnibpcajpcglclefindmkaj%26v%3D15.1.1.3%26installedby%3Dexternal%26uc", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(8);

	web_url("header.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/about", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("about.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/about.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/about", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("CONSENT=YES+RU.ru+20161009-18-0; DOMAIN=www.google.com");

	web_add_cookie("OGPC=19013527-1:19013805-1:; DOMAIN=www.google.com");

	web_add_cookie("ANID=AHWqTUk4-KLvFKHR1vJ6KgeZCsCXUp3nzw2eCzpjV95GrWH5fJx9adUpi-kBCq0C; DOMAIN=www.google.com");

	web_add_cookie("1P_JAR=2019-10-08-14; DOMAIN=www.google.com");

	web_add_cookie("NID=188=OcmjYnJJFjyZ2po9ZAQ2MngnmWDnl6hvQ1JiMGPo8h4L5-iBvEo33Lxm3q7mG0pggOq6AM0fAeNbrJ8X9zTvz-BJpoqJyoxy2HJAg4oNpeh40-9gnwWjsbJvSzHmTT6aQwEjDcx5ubSm-vQFQIEJ1DSSQ2hnWU3Sca6i8mE2r7sJxGa30l5myXq2fiDCuOn8OxCvEU-68QG4; DOMAIN=www.google.com");

	web_url("footerWhite.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/footerWhite.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/about", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://googleads.g.doubleclick.net/pagead/id", "Referer=https://www.youtube.com/embed/6Oukj5J_rZI", ENDITEM, 
		"Url=https://www.google.com/js/bg/Y127TbzHFt853-1VpJF27iywYTJTzUR5UBGBBrYp_xw.js", "Referer=https://www.youtube.com/embed/6Oukj5J_rZI", ENDITEM, 
		LAST);

	return 0;
}