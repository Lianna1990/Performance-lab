Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("test.uxcrowd.ru", 
		"URL=https://test.uxcrowd.ru/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/gulp/sup_css.css", ENDITEM, 
		"Url=/assets/css/landing/webflow.css", ENDITEM, 
		"Url=/assets/css/landing/uxcrowd.webflow.css", ENDITEM, 
		"Url=/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=/assets/gulp/env.js", ENDITEM, 
		"Url=/library/jquery.js", ENDITEM, 
		"Url=/library/jquery.form.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.js", ENDITEM, 
		"Url=/library/jquery.uploadfile.min.js", ENDITEM, 
		"Url=/library/FileSaver.js", ENDITEM, 
		"Url=/assets/gulp/sup_js.js", ENDITEM, 
		"Url=/assets/js/main_js/init.js", ENDITEM, 
		"Url=/assets/js/main_js/validation.rule.js", ENDITEM, 
		"Url=/assets/js/main_js/mediaelement-and-player.js", ENDITEM, 
		"Url=/assets/js/app_js/auth.interceptor.js", ENDITEM, 
		"Url=https://ulogin.ru/js/ulogin.js", ENDITEM, 
		"Url=/assets/gulp/app_js.js", ENDITEM, 
		"Url=/assets/gulp/admin_js.js", ENDITEM, 
		"Url=/assets/gulp/customer_js.js", ENDITEM, 
		"Url=/assets/gulp/blog_js.js", ENDITEM, 
		"Url=/assets/gulp/home_js.js", ENDITEM, 
		"Url=/assets/gulp/moderator_js.js", ENDITEM, 
		"Url=/assets/gulp/new_tester_js.js", ENDITEM, 
		"Url=/assets/gulp/tester_js.js", ENDITEM, 
		"Url=/library/require.js", ENDITEM, 
		"Url=/assets/js/main_js/path_controller.js", ENDITEM, 
		"Url=/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", ENDITEM, 
		"Url=/assets/js/main_js/main_route.js", ENDITEM, 
		"Url=https://ulogin-stats.ru/visit/", ENDITEM, 
		"Url=/controller/controller_home/newMain.controller.js?bust=1571393876505", ENDITEM, 
		"Url=/controller/controller_home/login.controller.js?bust=1571393876505", ENDITEM, 
		"Url=/app.js?bust=1571393876505", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ru.json", 
		"URL=https://test.uxcrowd.ru/assets/lang/ru.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://test.uxcrowd.ru/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"0ee1ca14-c44d-4e73-82f9-6a5cdf6da71f");

	web_url("headerGreenWhite.html", 
		"URL=https://test.uxcrowd.ru/tmpl/tmpl_landing_new/headerGreenWhite.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://test.uxcrowd.ru/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html", 
		"URL=https://test.uxcrowd.ru/tmpl/tmpl_landing_new/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://test.uxcrowd.ru/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footer.html", 
		"URL=https://test.uxcrowd.ru/tmpl/tmpl_landing_new/footer.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://test.uxcrowd.ru/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("dbl=71992f347b7e5be0405f47a31c090a6c; DOMAIN=test.uxcrowd.ru");

	web_add_cookie("fco2r34=71992f347b7e5be0405f47a31c090a6c; DOMAIN=test.uxcrowd.ru");

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_image("ux-logo-new-white.svg", 
		"Src=../../assets/images/ux-logo-new-white.svg", 
		"Snapshot=t6.inf", 
		EXTRARES, 
		"Url=/assets/css/landing/youtube-play.svg", "Referer=https://test.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=https://mc.yandex.ru/metrika/watch.js", "Referer=https://sale.aliexpress.com/ru/__pc/September_fashion_new_lianmeng.htm?tmLog=default_4625&aff_platform=promotion&cpt=1571393878939&sk=loa6aa3A&aff_trace_key=16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A&terminal_id=c42a423be07f48fd8db24940f5256235", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Origin", 
		"https://sale.aliexpress.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_submit_data("29739640", 
		"Action=https://mc.yandex.ru/watch/29739640?wmode=7&page-ref=https%3A%2F%2Ftest.uxcrowd.ru%2F&page-url=https%3A%2F%2Fsale.aliexpress.com%2Fru%2F__pc%2FSeptember_fashion_new_lianmeng.htm%3FtmLog%3Ddefault_4625%26aff_platform%3Dpromotion%26cpt%3D1571393878939%26sk%3Dloa6aa3A%26aff_trace_key%3D16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A%26terminal_id%3Dc42a423be07f48fd8db24940f5256235&charset=utf-8&browser-info="
		"ti%3A10%3Ans%3A1571393877100%3As%3A1920x1080x24%3Ask%3A1%3Aifr%3A1%3Asti%3A0%3Afpr%3A67501995301%3Acn%3A1%3Aw%3A6x6%3Az%3A180%3Ai%3A20191018131804%3Aet%3A1571393885%3Aen%3Autf-8%3Ac%3A1%3Ala%3Aru-ru%3Antf%3A1%3Acpf%3A1%3Apv%3A1%3Als%3A1015937737530%3Arqn%3A1%3Arn%3A611951905%3Ahid%3A51924914%3Ads%3A0%2C0%2C386%2C1068%2C3434%2C0%2C0%2C1732%2C50%2C%2C%2C%2C6630%3Awn%3A35394%3Ahl%3A1%3Agdpr%3A14%3Av%3A1728%3Arqnl%3A1%3Ast%3A1571393885%3Au%3A15713938851064002651", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://sale.aliexpress.com/ru/__pc/September_fashion_new_lianmeng.htm?tmLog=default_4625&aff_platform=promotion&cpt=1571393878939&sk=loa6aa3A&aff_trace_key=16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A&terminal_id=c42a423be07f48fd8db24940f5256235", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=../metrika/advert.gif", "Referer=https://sale.aliexpress.com/ru/__pc/September_fashion_new_lianmeng.htm?tmLog=default_4625&aff_platform=promotion&cpt=1571393878939&sk=loa6aa3A&aff_trace_key=16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A&terminal_id=c42a423be07f48fd8db24940f5256235", ENDITEM, 
		"Url=https://vk.com/rtrg?p=VK-RTRG-208363-3NOqH", "Referer=https://sale.aliexpress.com/ru/__pc/September_fashion_new_lianmeng.htm?tmLog=default_4625&aff_platform=promotion&cpt=1571393878939&sk=loa6aa3A&aff_trace_key=16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A&terminal_id=c42a423be07f48fd8db24940f5256235", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(11);

	web_custom_request("29739640_2", 
		"URL=https://mc.yandex.ru/watch/29739640?page-url=https%3A%2F%2Fsale.aliexpress.com%2Fru%2F__pc%2FSeptember_fashion_new_lianmeng.htm%3FtmLog%3Ddefault_4625%26aff_platform%3Dpromotion%26cpt%3D1571393878939%26sk%3Dloa6aa3A%26aff_trace_key%3D16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A%26terminal_id%3Dc42a423be07f48fd8db24940f5256235&charset=utf-8&force-urlencoded=1&browser-info="
		"ti%3A1%3Adp%3A1%3Ans%3A1571393877100%3As%3A1920x1080x24%3Ask%3A1%3Aifr%3A1%3Asti%3A0%3Aadb%3A2%3Afpr%3A67501995301%3Acn%3A1%3Aw%3A6x6%3Az%3A180%3Ai%3A20191018131823%3Aet%3A1571393903%3Aen%3Autf-8%3Ac%3A1%3Ala%3Aru-ru%3Antf%3A1%3Aar%3A1%3Anb%3A1%3Acl%3A746%3Als%3A1015937737530%3Arqn%3A2%3Arn%3A416657284%3Ahid%3A51924914%3Ads%3A%2C%2C%2C%2C%2C%2C%2C%2C%2C15213%2C15213%2C6%2C%3Agdpr%3A14%3Afu%3A1%3Av%3A1728%3Arqnl%3A1%3Ast%3A1571393903%3Au%3A15713938851064002651%3App%3A954964448", 
		"Method=POST", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://sale.aliexpress.com/ru/__pc/September_fashion_new_lianmeng.htm?tmLog=default_4625&aff_platform=promotion&cpt=1571393878939&sk=loa6aa3A&aff_trace_key=16d2c90c80624b17abd689478a173599-1571393878939-05094-loa6aa3A&terminal_id=c42a423be07f48fd8db24940f5256235", 
		"Snapshot=t8.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-XSRF-TOKEN", 
		"0ee1ca14-c44d-4e73-82f9-6a5cdf6da71f");

	web_url("modal-login.html", 
		"URL=https://test.uxcrowd.ru/tmpl/tmpl_home/modal-login.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://test.uxcrowd.ru/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}