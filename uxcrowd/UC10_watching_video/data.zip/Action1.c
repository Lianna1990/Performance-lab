Action1()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("prod.uxcrowd.ru", 
		"URL=http://prod.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/sup_css.css", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/webflow.css", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/uxcrowd.webflow.css", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/env.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.form.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/validation.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/jquery.uploadfile.min.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/FileSaver.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/sup_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/validation.rule.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/mediaelement-and-player.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/init.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/app_js/auth.interceptor.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/app_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://ulogin.ru/js/ulogin.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/admin_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/customer_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/blog_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/home_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/moderator_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/new_tester_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/gulp/tester_js.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/library/require.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/path_controller.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/landing/jQuery.YouTube.HD.Thumbnail.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/assets/js/main_js/main_route.js", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/controller/controller_home/newMain.controller.js?bust=1571662601923", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/controller/controller_home/login.controller.js?bust=1571662601923", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		"Url=https://prod.uxcrowd.ru/app.js?bust=1571662601923", "Referer=https://prod.uxcrowd.ru/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ru.json", 
		"URL=https://prod.uxcrowd.ru/assets/lang/ru.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-XSRF-TOKEN", 
		"0750574d-dff6-4a14-ba61-18b9d0d2a1c6");

	web_url("headerGreenWhite.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/headerGreenWhite.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/home.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("footer.html", 
		"URL=https://prod.uxcrowd.ru/tmpl/tmpl_landing_new/footer.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("ux-logo-new-white.svg", 
		"URL=https://prod.uxcrowd.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://prod.uxcrowd.ru/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/css/landing/youtube-play.svg", "Referer=https://prod.uxcrowd.ru/assets/css/landing/YouTube.HD.Thumbnail.css", ENDITEM, 
		"Url=https://ulogin-stats.ru/visit/", ENDITEM, 
		LAST);

	return 0;
}