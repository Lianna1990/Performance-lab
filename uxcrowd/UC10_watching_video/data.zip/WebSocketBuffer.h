#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 0 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive1[] = "";
long WebSocketReceiveLen1   = sizeof(WebSocketReceive1) - 1;	// (record-time: 0 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive2[] = "0xc43046ec80 |0| |";
long WebSocketReceiveLen2   = sizeof(WebSocketReceive2) - 1;	// (record-time: 18 bytes)

#endif
