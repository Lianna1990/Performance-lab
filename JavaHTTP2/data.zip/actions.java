import com.thoughtworks.xstream.*;
import java.io.*;
import javaHttpJ.*;
import javaHttpJ.parsers.*;
import javaHttpJ.replay.*;
import lrapi.*;

public class Actions
{
  public int init(){
    return 0;
  }

    public int end(){return 0;}


    public int action() throws Throwable{

	String ENDFORM      =  "ENDFORM";
	String LAST         =  "LAST";
	String ENDITEM      =  "ENDITEM";
	String ITEMDATA     =  "ITEMDATA";
	String STARTHIDDENS =  "STARTHIDDENS";
	String ENDHIDDENS   =  "ENDHIDDENS";
	String CONNECT	    =  "CONNECT";
	String RECEIVE      =  "RECEIVE";
	String RESOLVE	    =  "RESOLVE";
	String REQUEST      =  "REQUEST";
	String RESPONSE	    =  "RESPONSE";
	String EXTRARES     =  "EXTRARES";
	int _webresult; 

	try{

	lr.think_time(0);

	_webresult = lrapi.web.set_sockets_option("SSL_VERSION", "2&3");

	_webresult = lrapi.web.add_header("A-IM", 
		"x-bm,gzip");

	_webresult = lrapi.web.add_header("Accept-Encoding", 
		"gzip, deflate, br");

	_webresult = lrapi.web.add_header("If-None-Match", 
		"36c26d60ba6e3e639aa94fd26b47bd219988caef");

	_webresult = lrapi.web.add_header("Sec-Fetch-Site", 
		"none");

	_webresult = lrapi.web.add_header("User-Agent", 
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36");

	_webresult = lrapi.web.url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=77", new String[]{ 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		LAST})	// couldn't decode request from body. , couldn't decode response from body.%n
;

	}catch(Exception e){
		e.printStackTrace();
		return -1;
	}
	return 0;
    }

}